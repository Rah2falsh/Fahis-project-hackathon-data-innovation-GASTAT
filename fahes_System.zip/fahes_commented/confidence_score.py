"""
confidence_score.py
===================
Fahes (فاحص) — Statistical Survey Validation System
-----------------------------------------------------
This module computes a single Confidence Score (0.0 – 1.0) for each
survey record after errors have been classified.

Score interpretation
--------------------
  1.0   → No errors detected; data is fully trustworthy
  0.7+  → Minor issues; data is mostly reliable
  0.4–0.7 → Moderate problems; manual review recommended
  < 0.4 → Severe inconsistencies; data should not be used as-is

Scoring formula (penalty-based)
--------------------------------
  logical_score  = (# rule-engine errors)   / total_fields   (weight 0.6)
  semantic_score = (# semantic errors)       / total_fields   (weight 0.4)
  penalty        = 0.05 × total_error_count

  raw_penalty    = (w_rule × logical_score) + (w_semantic × semantic_score) - penalty
  confidence     = clamp(1 − raw_penalty, 0, 1)

Weights rationale
-----------------
  Rule-engine errors (logical, missing, outlier) receive a higher weight (0.6)
  because they represent hard, deterministic violations.
  Semantic mismatches (0.4) are probabilistic and may occasionally
  produce false positives due to model limitations.

Author  : Shahad Al-Obeid
Module  : Phase 5 — Confidence Score Calculation
"""


def calculate_confidence(classified_row, total_fields=7):
    """
    Compute the confidence score for a single classified survey record.

    Parameters
    ----------
    classified_row : dict — output from error_classifier.classify_errors()
        Expected structure:
        {
            "id":     <int>,
            "name":   <str>,
            "errors": [
                {
                    "field":      <str>,
                    "error_type": <str>,   # Arabic label
                    "detected":   True,
                    "source":     "rule_engine" | "semantic_model"
                },
                ...
            ],
            "clean":  <bool>
        }

    total_fields : int — number of validated fields per record (default 7).
        Used as the normalisation denominator so the per-field error rate
        stays in [0, 1] regardless of how many errors accumulate.

    Returns
    -------
    float — confidence score in [0.0, 1.0], rounded to 2 decimal places.
    """

    errors = classified_row.get("errors", [])

    # ── Fast Path: No Errors ───────────────────────────────────────────────────
    # A clean record receives the maximum possible score without computation.
    if not errors:
        return 1.0

    # ── Separate Errors by Source ──────────────────────────────────────────────
    # Rule-engine and semantic-model errors carry different reliability signals
    # and are weighted differently in the final penalty.
    rule_errors     = [e for e in errors if e["source"] == "rule_engine"]
    semantic_errors = [e for e in errors if e["source"] == "semantic_model"]

    num_rule     = len(rule_errors)
    num_semantic = len(semantic_errors)
    total_errors = len(errors)

    # ── Normalise Error Counts → Rates ────────────────────────────────────────
    # Dividing by total_fields converts raw counts into a 0-1 rate,
    # preventing scores from going negative when many errors are found.
    logical_score  = num_rule     / total_fields
    semantic_score = num_semantic / total_fields

    # ── Weighted Penalty Calculation ──────────────────────────────────────────
    w_rule     = 0.6   # Weight for deterministic rule-engine violations
    w_semantic = 0.4   # Weight for probabilistic semantic mismatches

    # Additional flat penalty for each extra error beyond the first,
    # reflecting the compounding risk of multiple data quality issues.
    penalty = 0.05 * total_errors

    # ── Combine Into Raw Penalty Score ───────────────────────────────────────
    confidence = (w_rule * logical_score) + (w_semantic * semantic_score) - penalty

    # ── Invert to Express as "Data Confidence" ────────────────────────────────
    # A higher penalty means lower confidence in the data.
    confidence = 1 - confidence

    # ── Clamp to Valid Range [0, 1] ───────────────────────────────────────────
    # Prevents mathematically possible but semantically invalid out-of-range values.
    confidence = max(0, min(1, confidence))

    return round(confidence, 2)
