"""
run_fahis_system.py
===================
Fahes (فاحص) — Statistical Survey Validation System
-----------------------------------------------------
This is the top-level entry point for running the complete Fahes pipeline
from the command line.  It orchestrates all four processing stages in order:

  Stage 1 — Rule Engine       : deterministic logical validation
  Stage 2 — Semantic Model    : embedding-based mismatch detection
  Stage 3 — Error Classifier  : merge & label errors from both sources
  Stage 4 — Output            : explanation + confidence score per record

Usage
-----
  Ensure the CSV dataset is in the same directory, then run:

      python run_fahis_system.py

Output format (per record)
--------------------------
  ══════════════════════════════════════════════════
  ID: <id> | Name: <name>
  Status: Clean ✅  |  Has Issues ❌
  - [<source>] <field> → <error_type>   (repeated per error)

  Explanation:
  <Arabic multi-line explanation>

  Confidence Score: <0.0 – 1.0>

Dependencies
------------
  All modules must be in the same directory:
    rule_engine.py, semantic_checker.py,
    explanation_generator.py, confidence_score.py

Author  : Rahaf Al-Shammari (integration)
Module  : Phase 7 — System Integration & UI (CLI mode)
"""

import pandas as pd

from rule_engine           import check_row
from semantic_checker      import run_semantic_checker
from explanation_generator import generate_explanation
from confidence_score      import calculate_confidence

# ── Configuration ──────────────────────────────────────────────────────────────
FILE_NAME = "fahis_mock_data.csv"   # Path to the survey dataset


# ── Error Classification (Internal Pipeline Step) ─────────────────────────────

def classify_errors(df):
    """
    Internal aggregation step: merge rule-engine and semantic-model results
    into a single list of classified records.

    This function mirrors error_classifier.classify_errors() but is kept
    local to this module so the entry-point script remains self-contained
    and does not introduce a circular import with error_classifier.py.

    Parameters
    ----------
    df : pd.DataFrame — full survey dataset

    Returns
    -------
    list of classified record dicts:
    {
        "id":     <int>,
        "name":   <str>,
        "errors": [ {"field", "error_type", "source"}, ... ],
        "clean":  <bool>
    }
    """
    classified = []

    # ── Run Semantic Checker Once ──────────────────────────────────────────────
    # Batch inference across all rows is significantly faster than calling
    # the model one row at a time inside the loop below.
    semantic_results = run_semantic_checker(df)
    semantic_map     = {r["id"]: r for r in semantic_results}

    for _, row in df.iterrows():
        row_id = row["id"]
        errors = []

        # ── Rule Engine ────────────────────────────────────────────────────────
        rule_errors = check_row(row)
        for err in rule_errors:
            errors.append({
                "field":      err["field"],
                "error_type": err["error_type"],
                "source":     "rule_engine"
            })

        # ── Semantic Model ─────────────────────────────────────────────────────
        semantic = semantic_map.get(row_id)
        if semantic and semantic["detected_mismatch"]:
            errors.append({
                "field":      "major + job_title",
                "error_type": "تناقض دلالي",
                "source":     "semantic_model"
            })

        classified.append({
            "id":     row_id,
            "name":   row.get("name", ""),
            "errors": errors,
            "clean":  len(errors) == 0
        })

    return classified


# ── Main Pipeline ─────────────────────────────────────────────────────────────

def main():
    """
    Full Fahes pipeline execution:
      1. Load dataset from CSV.
      2. Classify all records (rule engine + semantic model).
      3. For each record, print status, errors, explanation, and confidence score.

    Run with:  python run_fahis_system.py
    """

    # ── Stage 1: Load Data ─────────────────────────────────────────────────────
    print("Loading data...")
    df = pd.read_csv(FILE_NAME)

    # ── Stage 2 & 3: Classify Errors (rule + semantic + merge) ────────────────
    print("Running Fahis System...\n")
    classified = classify_errors(df)

    # ── Stage 4: Print Final Results ───────────────────────────────────────────
    print("===== FINAL RESULTS =====")

    for row in classified:
        print("\n" + "=" * 50)
        print(f"ID: {row['id']} | Name: {row['name']}")

        # ── Validation Status ──────────────────────────────────────────────────
        if row["clean"]:
            print("Status: Clean ✅")
        else:
            print("Status: Has Issues ❌")
            # List every detected error with its source module and field name
            for err in row["errors"]:
                print(f"- [{err['source']}] {err['field']} → {err['error_type']}")

        # ── Arabic Explanation ─────────────────────────────────────────────────
        # generate_explanation() maps error types to human-readable Arabic text.
        explanation = generate_explanation(row)
        print("\nExplanation:")
        print(explanation)

        # ── Confidence Score ───────────────────────────────────────────────────
        # calculate_confidence() returns a float in [0, 1] based on error count
        # and source weights.
        confidence = calculate_confidence(row)
        print(f"\nConfidence Score: {confidence}")

    print("\n===== DONE =====")


# ── Guard: Only execute when run directly ─────────────────────────────────────
if __name__ == "__main__":
    main()
