"""
rule_engine.py
==============
Fahes (فاحص) — Statistical Survey Validation System
-----------------------------------------------------
This module implements the deterministic rule-based validation layer.
It scans each survey row for:
  - Missing or empty required fields
  - Logical contradictions (e.g., impossible years of experience for a given age)
  - Outlier values (e.g., salary too high/low relative to experience & education)

All detected errors are returned as structured dictionaries with an Arabic
error_type label, enabling downstream modules (confidence scorer, explanation
generator) to process them uniformly.

Author  : Ghaid Al-Oqaili
Module  : Phase 2 — Rule-Based Validation Engine
"""

import pandas as pd
import sys

# Ensure the terminal prints Arabic characters correctly on all platforms
sys.stdout.reconfigure(encoding='utf-8')

# ── Data Source ────────────────────────────────────────────────────────────────
# Path to the survey CSV dataset used when running this module standalone
FILE_NAME = "fahis_mock_data.csv"

# ── Schema Definition ─────────────────────────────────────────────────────────
# All columns that must be present in every survey record
REQUIRED_COLUMNS = [
    "id",
    "age",
    "education",
    "major",
    "job_title",
    "years_experience",
    "salary"
]

# Arabic error type labels used as ground-truth labels in the dataset
# and as the vocabulary for detected error classification
TARGET_ERROR_TYPES = ["خطأ منطقي", "قيمة شاذة", "بيانات ناقصة"]


# ── Text Normalisation Helpers ─────────────────────────────────────────────────

def normalize_text(value):
    """
    Convert any cell value to a lowercase, stripped string.
    Returns an empty string for NaN / None values so downstream
    comparisons never raise TypeError.
    """
    if pd.isna(value):
        return ""
    return str(value).strip().lower()


def normalize_education(value):
    """
    Map both Arabic and English education labels to a canonical Arabic form.
    This ensures bilingual survey responses are compared consistently.

    Examples
    --------
    "Bachelor"  → "بكالوريوس"
    "ماجستير"   → "ماجستير"
    "PhD"       → "دكتوراه"
    """
    text = normalize_text(value)

    mapping = {
        # High school variants
        "ثانوي":      "ثانوي",
        "high school": "ثانوي",
        "secondary":   "ثانوي",
        # Diploma variants
        "دبلوم":  "دبلوم",
        "diploma": "دبلوم",
        # Bachelor variants
        "بكالوريوس": "بكالوريوس",
        "bachelor":   "بكالوريوس",
        "bachelors":  "بكالوريوس",
        # Master variants
        "ماجستير": "ماجستير",
        "master":   "ماجستير",
        "masters":  "ماجستير",
        # Doctorate variants
        "دكتوراه":  "دكتوراه",
        "phd":      "دكتوراه",
        "doctorate": "دكتوراه"
    }

    return mapping.get(text, text)


def to_number(value):
    """
    Safely parse a cell value to float, stripping common currency symbols
    and thousand-separator commas.  Returns None if the value is empty or
    cannot be parsed — the caller treats None as a data-quality signal.

    Handled formats: "15,000", "8000 SAR", "٢٠٠٠٠ ريال", "$5000"
    """
    if pd.isna(value):
        return None

    text = str(value).strip()

    if text == "":
        return None

    # Strip currency decorators before numeric parsing
    text = text.replace(",", "")
    text = text.replace("sar", "")
    text = text.replace("ريال", "")
    text = text.replace("$", "")
    text = text.strip()

    try:
        return float(text)
    except ValueError:
        return None


# ── Schema Guard ──────────────────────────────────────────────────────────────

def validate_columns(df):
    """
    Raise ValueError if any required column is absent from the DataFrame.
    Must be called once after loading the CSV before per-row validation begins.
    """
    missing = [col for col in REQUIRED_COLUMNS if col not in df.columns]

    if missing:
        raise ValueError(f"Missing required columns: {missing}")


# ── Error Accumulator ─────────────────────────────────────────────────────────

def add_error(errors, field, error_type, reason):
    """
    Append an error entry to the errors list only if an identical
    (field, error_type) pair does not already exist.  This prevents
    duplicate entries when multiple rules fire on the same field.

    Parameters
    ----------
    errors     : list  — mutable error list for the current row
    field      : str   — column name where the error was detected
    error_type : str   — Arabic category label (e.g., "خطأ منطقي")
    reason     : str   — short English description for logging / debugging
    """
    for error in errors:
        if error["field"] == field and error["error_type"] == error_type:
            return   # duplicate — skip

    errors.append({
        "field":      field,
        "error_type": error_type,
        "detected":   True,
        "reason":     reason
    })


# ── Missing-Field Check ───────────────────────────────────────────────────────

def check_missing_fields(row):
    """
    Iterate over every required column (except 'id') and flag any that
    are NaN or contain only whitespace.

    Returns
    -------
    list of error dicts — empty if all fields are populated
    """
    errors = []

    for field in REQUIRED_COLUMNS:
        if field == "id":
            continue   # 'id' is a record identifier, not a data quality field

        value = row[field]

        if pd.isna(value) or (isinstance(value, str) and value.strip() == ""):
            add_error(errors, field, "بيانات ناقصة", f"{field} is missing")

    return errors


# ── Per-Row Logical Validation ────────────────────────────────────────────────

def check_row(row):
    """
    Apply all rule-based validations to a single survey row.

    Processing order
    ----------------
    1. Missing-field check  — if any field is absent, return early
       (downstream numeric rules require all fields to be present).
    2. Parse numeric fields (age, experience, salary).
    3. Apply logical contradiction rules.
    4. Apply salary-anomaly rules.

    Returns
    -------
    list of error dicts — empty list means the row passed all rules.
    """
    errors = []

    # Step 1: Missing fields take priority — return immediately if found
    missing_errors = check_missing_fields(row)
    if missing_errors:
        return missing_errors

    # Step 2: Parse numeric values; flag unparseable entries
    age        = to_number(row["age"])
    experience = to_number(row["years_experience"])
    salary     = to_number(row["salary"])
    education  = normalize_education(row["education"])

    if age is None:
        add_error(errors, "age", "بيانات ناقصة", "age is invalid")

    if experience is None:
        add_error(errors, "years_experience", "بيانات ناقصة",
                  "years_experience is invalid")

    if salary is None:
        add_error(errors, "salary", "بيانات ناقصة", "salary is invalid")

    # Abort further numeric rules if any parse failed
    if errors:
        return errors

    # ── Logical Contradiction Rules ───────────────────────────────────────────

    # Rule L-1: A person can realistically start working no earlier than age 18.
    #           Experience that exceeds (age - 18) is physically impossible.
    max_possible_exp = age - 18
    if experience > max_possible_exp:
        add_error(
            errors,
            "years_experience",
            "خطأ منطقي",
            "years of experience exceeds possible working years for age"
        )

    # Rule L-2: 10+ years of experience at age ≤ 24 is implausible.
    if age <= 24 and experience >= 10:
        add_error(
            errors,
            "years_experience",
            "خطأ منطقي",
            "years of experience is too high for a young age"
        )

    # ── Salary Anomaly Rules ──────────────────────────────────────────────────

    # Rule S-1: Salary above 20k SAR with ≤ 2 years experience is an outlier.
    if experience <= 2 and salary >= 20000:
        add_error(
            errors,
            "salary",
            "قيمة شاذة",
            "salary too high for low experience"
        )

    # Rule S-2: High school / diploma holders with ≤ 3 years exp
    #           earning above 22k SAR is statistically anomalous.
    if education in ["ثانوي", "دبلوم"] and experience <= 3 and salary >= 22000:
        add_error(
            errors,
            "salary",
            "قيمة شاذة",
            "salary too high for qualification and low experience"
        )

    # Rule S-3: A salary below 4k SAR for someone with 10+ years experience
    #           is suspiciously low — likely a data entry error.
    if experience >= 10 and salary < 4000:
        add_error(
            errors,
            "salary",
            "قيمة شاذة",
            "salary too low for high experience"
        )

    return errors


# ── Evaluation Helper ─────────────────────────────────────────────────────────

def evaluate_detection(df, detected_rows):
    """
    Measure rule-engine detection accuracy against the ground-truth
    'error_type' column in the dataset.

    Only rows whose expected error_type is in TARGET_ERROR_TYPES are counted;
    rows labelled 'لا يوجد' (no error) or with unknown labels are ignored.

    Parameters
    ----------
    df            : pd.DataFrame — full dataset with 'error_type' column
    detected_rows : list of dicts — output from the main validation loop

    Returns
    -------
    dict with keys: total_target_errors, correctly_detected, detection_accuracy
    Returns None if the dataset has no 'error_type' column.
    """
    correct       = 0
    total_target  = 0
    detected_map  = {item["row_index"]: item["errors"] for item in detected_rows}

    if "error_type" not in df.columns:
        return None

    for index, row in df.iterrows():
        expected_error = row["error_type"]

        if expected_error in TARGET_ERROR_TYPES:
            total_target += 1
            row_errors     = detected_map.get(index, [])
            detected_types = [err["error_type"] for err in row_errors]

            if expected_error in detected_types:
                correct += 1

    accuracy = correct / total_target if total_target > 0 else 0

    return {
        "total_target_errors": total_target,
        "correctly_detected":  correct,
        "detection_accuracy":  accuracy
    }


# ── Standalone Entry Point ────────────────────────────────────────────────────

def main():
    """
    Load the survey CSV, run the rule engine on every row, print detected
    errors to stdout, and report overall detection accuracy.
    Run with:  python rule_engine.py
    """
    df = pd.read_csv(FILE_NAME)
    validate_columns(df)

    detected_rows = []

    for index, row in df.iterrows():
        row_errors = check_row(row)

        if row_errors:
            detected_rows.append({
                "row_index": index,
                "id":        row["id"],
                "errors":    row_errors
            })

    # ── Print Results ─────────────────────────────────────────────────────────
    print("Detected Rows:")
    for item in detected_rows:
        print(f"\nID {item['id']}:")
        for err in item["errors"]:
            print(f"  - {err}")

    # ── Print Accuracy Metrics ────────────────────────────────────────────────
    evaluation = evaluate_detection(df, detected_rows)
    if evaluation:
        print("\nEvaluation:")
        print("Total target errors:", evaluation["total_target_errors"])
        print("Correctly detected:", evaluation["correctly_detected"])
        print("Detection accuracy:", evaluation["detection_accuracy"])


if __name__ == "__main__":
    main()
