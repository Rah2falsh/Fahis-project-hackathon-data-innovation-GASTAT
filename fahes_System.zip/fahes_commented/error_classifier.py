"""
error_classifier.py
===================
Fahes (فاحص) — Statistical Survey Validation System
-----------------------------------------------------
This module is the central aggregation layer of the Fahes pipeline.
It merges outputs from the rule-based engine and the semantic model
into a single, unified error classification per survey record.

Supported error types (Arabic labels)
--------------------------------------
  "خطأ منطقي"    — Logical contradiction    (source: rule_engine)
  "قيمة شاذة"   — Outlier / anomalous value (source: rule_engine)
  "بيانات ناقصة" — Missing data             (source: rule_engine)
  "تناقض دلالي"  — Semantic mismatch        (source: semantic_model)

Design notes
------------
- The semantic checker is executed once on the full DataFrame and its
  results are indexed by record 'id' for O(1) lookup during row iteration,
  avoiding redundant model inference calls.
- A record is marked 'clean' only when both sources report zero errors.

Author  : Leen Al-Masri
Module  : Phase 4 — Error Classification
"""

import pandas as pd
from rule_engine      import check_row
from semantic_checker import run_semantic_checker, model   # reuse loaded model

# ── Configuration ──────────────────────────────────────────────────────────────
FILE_NAME = "fahis_mock_data.csv"   # Input dataset path (standalone mode)


# ── Main Classification Function ───────────────────────────────────────────────

def classify_errors(df):
    """
    Combine rule-engine and semantic-model outputs into a unified
    per-record classification list.

    Processing flow per record
    --------------------------
    1. Look up pre-computed semantic result by record 'id'.
    2. Run the rule engine on the row (fast, deterministic).
    3. Append rule errors tagged with source="rule_engine".
    4. If the semantic checker flagged a mismatch, append a
       semantic error tagged with source="semantic_model".
    5. Mark the record as 'clean' if the combined error list is empty.

    Parameters
    ----------
    df : pd.DataFrame — survey dataset loaded from CSV.

    Returns
    -------
    list of dicts, each representing one classified record:
    {
        "id":     <int>,
        "name":   <str>,
        "errors": [
            {
                "field":      <str>,    # column(s) involved
                "error_type": <str>,    # Arabic label
                "detected":   True,
                "source":     "rule_engine" | "semantic_model"
            },
            ...
        ],
        "clean":  <bool>   # True if no errors from either source
    }
    """
    classified = []

    # ── Run Semantic Checker Once ──────────────────────────────────────────────
    # Running inference row-by-row would be wasteful; batch the entire DataFrame
    # and convert results to a dict keyed by 'id' for O(1) lookup below.
    semantic_results = run_semantic_checker(df)
    semantic_map     = {r["id"]: r for r in semantic_results}

    for _, row in df.iterrows():
        row_id = row["id"]
        errors = []

        # ── Rule Engine Errors ─────────────────────────────────────────────────
        # check_row() returns a list of structured error dicts.
        # We enrich each entry with a 'source' tag before appending.
        rule_errors = check_row(row)
        for err in rule_errors:
            errors.append({
                "field":      err["field"],
                "error_type": err["error_type"],
                "detected":   True,
                "source":     "rule_engine"
            })

        # ── Semantic Model Errors ──────────────────────────────────────────────
        # Append a semantic error entry only when the checker reported a mismatch
        # for this record.  The field label "major + job_title" signals that the
        # conflict spans two columns simultaneously.
        semantic = semantic_map.get(row_id)
        if semantic and semantic["detected_mismatch"]:
            errors.append({
                "field":      "major + job_title",
                "error_type": "تناقض دلالي",
                "detected":   True,
                "source":     "semantic_model"
            })

        # ── Assemble Classified Record ─────────────────────────────────────────
        classified.append({
            "id":     row_id,
            "name":   row.get("name", ""),
            "errors": errors,
            "clean":  len(errors) == 0   # True only when both sources are clear
        })

    return classified


# ── Evaluation Helper ─────────────────────────────────────────────────────────

def evaluate(classified, df):
    """
    Measure overall classification accuracy by comparing detected errors
    against the ground-truth 'error_type' column.

    A row is counted as correctly classified when:
      - Expected label is "لا يوجد" (no error) AND no errors were detected, OR
      - Expected label matches one of the detected error_type values.

    Parameters
    ----------
    classified : list of dicts — output of classify_errors()
    df         : pd.DataFrame — original dataset with 'error_type' column

    Returns
    -------
    dict with keys: total, correct, accuracy (float rounded to 2 dp)
    """
    correct   = 0
    total     = len(df)

    # Index classified results by 'id' for fast ground-truth comparison
    error_map = {r["id"]: r["errors"] for r in classified}

    for _, row in df.iterrows():
        expected       = str(row.get("error_type", "")).strip()
        detected_types = [e["error_type"] for e in error_map.get(row["id"], [])]

        if expected == "لا يوجد" and len(detected_types) == 0:
            # True negative: clean record correctly identified as clean
            correct += 1
        elif expected != "لا يوجد" and expected in detected_types:
            # True positive: expected error type was detected
            correct += 1

    return {
        "total":    total,
        "correct":  correct,
        "accuracy": round(correct / total, 2)
    }


# ── Standalone Entry Point ────────────────────────────────────────────────────

if __name__ == "__main__":
    """
    Load the dataset, classify all records, print a detailed report,
    and display overall accuracy metrics.
    Run with:  python error_classifier.py
    """
    df         = pd.read_csv(FILE_NAME)
    classified = classify_errors(df)

    print("Classification Results:")
    print("-" * 60)

    for r in classified:
        if not r["clean"]:
            # Print each error grouped under the record's ID and name
            print(f"\nID {r['id']} | {r['name']}")
            for err in r["errors"]:
                print(f"  [{err['source']}] {err['field']} → {err['error_type']}")
        else:
            print(f"ID {r['id']} | {r['name']:<20} | clean ✓")

    print("\n" + "-" * 60)
    ev = evaluate(classified, df)
    print(f"Total rows : {ev['total']}")
    print(f"Correct    : {ev['correct']}")
    print(f"Accuracy   : {ev['accuracy']}")
