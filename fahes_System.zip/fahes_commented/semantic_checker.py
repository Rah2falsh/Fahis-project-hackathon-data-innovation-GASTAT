"""
semantic_checker.py
===================
Fahes (فاحص) — Statistical Survey Validation System
-----------------------------------------------------
This module implements the AI-powered semantic validation layer.
It detects semantic mismatches between a respondent's academic major
and their declared job title by computing cosine similarity between
multilingual sentence embeddings.

Key design decisions
--------------------
- Model : paraphrase-multilingual-MiniLM-L12-v2
    Chosen for its strong cross-lingual performance on Arabic + English text
    with a compact size suitable for CPU inference.
- Threshold : 0.35
    Pairs scoring below this value are flagged as semantic mismatches.
    Calibrated empirically against the Fahes mock dataset.
- Special case : major == "لا يوجد" (no major)
    Automatically treated as a mismatch because no embedding comparison
    is meaningful when one side of the pair is absent.

Author  : Leen Al-Masri
Module  : Phase 3 — Semantic Analysis Model
"""

import pandas as pd
from sentence_transformers import SentenceTransformer, util

# ── Configuration ──────────────────────────────────────────────────────────────
MODEL_NAME = "paraphrase-multilingual-MiniLM-L12-v2"   # HuggingFace model ID
FILE_NAME  = "fahis_mock_data.csv"                      # Input dataset path
THRESHOLD  = 0.35   # Cosine-similarity cut-off; scores below → semantic mismatch

# ── Model Loading ──────────────────────────────────────────────────────────────
# The model is loaded once at import time so all callers share the same instance.
# Loading is slow (~2–5 s on first run due to weight downloads / disk reads);
# subsequent imports within the same Python process reuse the cached object.
print("Loading model, please wait...")
model = SentenceTransformer(MODEL_NAME)
print("Model loaded successfully!")


# ── Core Similarity Function ───────────────────────────────────────────────────

def get_similarity_score(major, job_title):
    """
    Compute the cosine similarity between the embeddings of *major* and
    *job_title* using the loaded multilingual sentence transformer.

    Parameters
    ----------
    major     : str — respondent's academic field (Arabic or English)
    job_title : str — respondent's declared occupation (Arabic or English)

    Returns
    -------
    float in [-1, 1] rounded to 3 decimal places, or None if either
    input is empty (prevents meaningless comparisons).

    Notes
    -----
    - Cosine similarity of 1.0  → perfectly aligned fields
    - Values near 0 or negative → semantically unrelated fields
    - The THRESHOLD constant defines the acceptance boundary.
    """
    if not major or not job_title:
        return None

    # Encode both texts into dense vectors in one batched call (more efficient)
    embeddings = model.encode([major, job_title], convert_to_tensor=True)
    score      = util.cos_sim(embeddings[0], embeddings[1]).item()
    return round(score, 3)


# ── Batch Checker ─────────────────────────────────────────────────────────────

def run_semantic_checker(df):
    """
    Run semantic mismatch detection across every row in the DataFrame.

    For each record the function:
      1. Extracts the 'major' and 'job_title' fields.
      2. Handles the "لا يوجد" (no major) edge case.
      3. Computes cosine similarity and compares against THRESHOLD.
      4. Appends a result dict regardless of outcome so downstream modules
         can match results by 'id' without gaps.

    Parameters
    ----------
    df : pd.DataFrame — survey dataset; must contain 'id', 'major',
                        'job_title', and optionally 'error_type' columns.

    Returns
    -------
    list of dicts, each containing:
        id                : record identifier
        major             : raw major value from the row
        job_title         : raw job title value from the row
        similarity_score  : float or None
        detected_mismatch : bool — True if mismatch was detected
        expected_error    : ground-truth label (empty string if column absent)
    """
    results = []

    for _, row in df.iterrows():
        major     = str(row.get("major",      "")).strip()
        job_title = str(row.get("job_title",  "")).strip()
        expected  = str(row.get("error_type", "")).strip()

        # Skip rows where pandas has serialised missing values as the string "nan"
        if major == "nan" or job_title == "nan":
            continue

        # ── Special Case: No Major ─────────────────────────────────────────────
        # A respondent with no academic major cannot have a meaningful similarity
        # score. Flag immediately as a mismatch without embedding computation.
        if major == "لا يوجد":
            results.append({
                "id":                row["id"],
                "major":             major,
                "job_title":         job_title,
                "similarity_score":  None,
                "detected_mismatch": True,
                "expected_error":    expected
            })
            continue

        # ── Standard Path: Embedding Comparison ───────────────────────────────
        score       = get_similarity_score(major, job_title)
        is_mismatch = score is not None and score < THRESHOLD

        results.append({
            "id":                row["id"],
            "major":             major,
            "job_title":         job_title,
            "similarity_score":  score,
            "detected_mismatch": is_mismatch,
            "expected_error":    expected
        })

    return results


# ── Evaluation Helper ─────────────────────────────────────────────────────────

def evaluate(results):
    """
    Compare detected semantic mismatches against ground-truth labels.
    Only rows labelled "تناقض دلالي" in the dataset are counted as
    positive targets.

    Parameters
    ----------
    results : list of dicts — output of run_semantic_checker()

    Returns
    -------
    dict with keys:
        total_target       : int   — number of ground-truth mismatches
        correctly_detected : int   — true positives
        accuracy           : float — correctly_detected / total_target
    """
    total_target       = sum(1 for r in results if r["expected_error"] == "تناقض دلالي")
    correctly_detected = sum(
        1 for r in results
        if r["expected_error"] == "تناقض دلالي" and r["detected_mismatch"]
    )

    accuracy = correctly_detected / total_target if total_target > 0 else 0

    return {
        "total_target":       total_target,
        "correctly_detected": correctly_detected,
        "accuracy":           round(accuracy, 2)
    }


# ── Standalone Entry Point ────────────────────────────────────────────────────

if __name__ == "__main__":
    """
    Load the survey CSV, run semantic checking on all rows, print a
    per-row status table, and report accuracy metrics.
    Run with:  python semantic_checker.py
    """
    df      = pd.read_csv(FILE_NAME)
    results = run_semantic_checker(df)

    print("\nDetected / Expected Semantic Mismatches:")
    print("-" * 60)

    for r in results:
        # Print only rows that are either detected or expected to be mismatches
        if r["detected_mismatch"] or r["expected_error"] == "تناقض دلالي":
            status = "✓" if r["detected_mismatch"] else "✗"
            score  = r["similarity_score"] if r["similarity_score"] is not None else "N/A"
            print(
                f"[{status}] ID {r['id']:>2} | "
                f"{r['major']:<20} + {r['job_title']:<30} | "
                f"score: {score}"
            )

    print("-" * 60)
    ev = evaluate(results)
    print(f"Total semantic errors : {ev['total_target']}")
    print(f"Correctly detected    : {ev['correctly_detected']}")
    print(f"Accuracy              : {ev['accuracy']}")
