"""
explanation_generator.py
========================
Fahes (فاحص) — Statistical Survey Validation System
-----------------------------------------------------
This module generates human-readable, Arabic-language explanations for
every error detected in a classified survey record.

Design philosophy
-----------------
- Explanations are intentionally non-static: the intro sentence is drawn
  randomly from a pool of alternatives so that users who review multiple
  flagged records do not see identical boilerplate text every time.
- Each error type maps to a dedicated explanation template that references
  the specific field name, making the message actionable rather than generic.
- The module is self-contained; it does not call any external AI service,
  keeping latency low and the system operable offline.  An LLM integration
  (e.g., Allam) can be added in a future iteration for richer explanations.

Supported error types
---------------------
  "خطأ منطقي"    → Describes the logical contradiction in plain Arabic
  "قيمة شاذة"   → Flags that the value falls outside expected patterns
  "بيانات ناقصة" → Notes that the field is incomplete
  "تناقض دلالي"  → Explains the major–job semantic conflict
  <unknown>      → Falls back to a generic message with the raw error type

Author  : Shahad Al-Obeid
Module  : Phase 6 — Explanation Generation
"""

import random


def generate_explanation(classified_row):
    """
    Produce an Arabic explanation string for a single classified record.

    If the record has no errors the function returns a short confirmation
    that the data appears consistent.  Otherwise it selects a random
    introductory sentence and appends one bullet point per detected error.

    Parameters
    ----------
    classified_row : dict — output entry from error_classifier.classify_errors()
        Expected structure:
        {
            "id":     <int>,
            "name":   <str>,
            "errors": [
                {
                    "field":      <str>,
                    "error_type": <str>,   # Arabic label
                    "detected":   True,
                    "source":     "rule_engine" | "semantic_model"
                }
            ],
            "clean":  <bool>
        }

    Returns
    -------
    str — multi-line Arabic explanation.
        First line : dynamic intro (or clean-record confirmation).
        Subsequent lines : one bullet (•) per detected error.
    """

    errors = classified_row.get("errors", [])

    # ── Clean Record: No Errors ────────────────────────────────────────────────
    # Return a brief confirmation message without bullet points.
    if not errors:
        return "البيانات تبدو متناسقة ولا توجد مشاكل واضحة"

    # ── Dynamic Introduction ───────────────────────────────────────────────────
    # Three semantically equivalent intro sentences are randomly sampled so that
    # repeated reads of different error reports feel less formulaic.
    intros = [
        "تحليل البيانات يشير إلى وجود بعض المشكلات التي تحتاج مراجعة:",
        "تم اكتشاف عدد من التناقضات في البيانات المدخلة:",
        "النظام لاحظ وجود تعارضات محتملة في المعلومات المقدمة:"
    ]

    explanations = [random.choice(intros)]

    # ── Per-Error Bullet Points ────────────────────────────────────────────────
    # Each error type receives a tailored template that embeds the field name
    # so the data-entry operator knows exactly which value to revisit.
    for err in errors:
        field      = err.get("field", "")
        error_type = err.get("error_type", "")

        if error_type == "خطأ منطقي":
            # Logical contradiction: the field value conflicts with related fields.
            explanations.append(
                f"• هناك عدم توافق منطقي في الحقل '{field}' "
                f"مقارنة بالعلاقات الطبيعية بين البيانات."
            )

        elif error_type == "قيمة شاذة":
            # Outlier: the value is statistically unusual for the record's profile.
            explanations.append(
                f"• القيمة المدخلة في '{field}' تبدو خارج النطاق المتوقع "
                f"مقارنة بالأنماط الشائعة."
            )

        elif error_type == "بيانات ناقصة":
            # Missing data: the field was left empty or contained an invalid value.
            explanations.append(
                f"• الحقل '{field}' غير مكتمل مما قد يؤثر على دقة التحليل."
            )

        elif error_type == "تناقض دلالي":
            # Semantic mismatch: the model detected a conceptual gap between
            # the academic major and the declared job title.
            explanations.append(
                "• يوجد تعارض دلالي بين التخصص والوظيفة "
                "بناءً على تحليل المعنى."
            )

        else:
            # Fallback for any future error types not yet covered by templates.
            explanations.append(
                f"• تم رصد مشكلة في '{field}' من نوع: {error_type}"
            )

    # Join intro + bullet lines with newlines into a single readable string.
    return "\n".join(explanations)
